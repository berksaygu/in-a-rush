using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Timer : MonoBehaviour
{
    public Text timerText;
    private float startTime;
    private bool finished = false;
    private float t;
    private string minutes;
    private string seconds;

    private float minute;
    private float second;
    private float point;
    private float score;
    // Start is called before the first frame update
    void Start()
    {
        startTime = Time.time;
        point = 1200.0f;
    }
    // Update is called once per frame
    void Update()
    {
        if (finished == true)
        {
            timerText.text = minutes + ": " + seconds;

        }
        else if (finished == false)
        {
            t = Time.time - startTime;
            minutes = ((int)t / 60).ToString();
            seconds = (t % 60).ToString("f1");
            timerText.text = minutes + ":" + seconds;
            minute = float.Parse(minutes);
            second = float.Parse(seconds);
            score = minute*60 + second;
        }
    }
    private void Finish()
    {
        finished = true;
        timerText.color = Color.yellow;
        Debug.Log(score);

    }    
    public int getScore()
    {
        point = point - score;
        if(point <= 0)// hayvan degilsen yap 1200 den �nce
        {
            SceneManager.LoadScene(3);
        }
        return (int)point;
    }
   
}