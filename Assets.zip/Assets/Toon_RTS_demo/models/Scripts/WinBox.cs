using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class WinBox : MonoBehaviour
{
    public PlayFabManager playFabManager;
    public Timer timer;
    public void OnTriggerEnter(Collider other)
    {
    GameObject.Find("Player").SendMessage("Finish");
        playFabManager.SendLeaderboard(timer.getScore());
        
    }
   
      
}
