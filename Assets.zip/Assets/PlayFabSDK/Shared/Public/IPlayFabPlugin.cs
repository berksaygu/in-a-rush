﻿namespace PlayFab
{
    /// <summary>
    /// Base interface of any PlayFab SDK plugin.
    /// </summary>
    public interface IPlayFabPlugin
    {
    }
}