using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class UIController : MonoBehaviour
{
    [SerializeField] TMP_Text scoreLabel;
    [SerializeField] SettingsPopUp settingsPopup;


    void Start()
    {        
        //settingsPopup.Close();
    }
    public void OnOpenSettings()
    {
        Debug.Log("open settings");
        settingsPopup.Open();

    }
    public void CloseOpenSettings()
    {
        settingsPopup.Close();


    }
    public void PlayButton()
    {
        SceneManager.LoadScene(3);
    }
    public void QuitButton()
    {
        Application.Quit();
    }
    public void ControlsButton()
    {
        SceneManager.LoadScene(2);
    }
    public void backToMenuButton()
    {
        SceneManager.LoadScene(1);
    }
    public void LeaderboardButton()
    {
        SceneManager.LoadScene(4);
    }
}
